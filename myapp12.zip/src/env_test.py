import __init__

env = __init__.get_env_variable("DATABASE_URI")
print(env)